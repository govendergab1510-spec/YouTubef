package dev.opentube

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

/** Infinite-scroll list state. */
class Feed(private val load: Loader, private val scope: CoroutineScope) {
    var items by mutableStateOf(listOf<Vid>()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    private var next: Page? = null
    private var started = false
    private var end = false

    fun more() {
        if (loading || end) return
        loading = true; error = null
        scope.launch {
            try {
                val pg = load(if (started) next else null)
                started = true; next = pg.next; end = pg.next == null
                val seen = items.mapTo(HashSet()) { it.url }
                items = items + pg.items.filter { seen.add(it.url) }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { error = e.message?.take(140) ?: "Couldn't load videos" }
            loading = false
        }
    }
}

class ChanUi(val c: Chan, val feed: Feed)

class AppVm : ViewModel() {
    /* home */
    val chips = listOf("All", "Music", "Gaming", "Live", "News", "Podcasts", "Movies", "Sports", "Coding", "Cooking", "Travel")
    var chip by mutableStateOf("All"); private set
    var home by mutableStateOf(mk("All")); private set
    private fun mk(c: String) = Feed(if (c == "All") Repo.trending() else Repo.search(if (c == "Live") "live now" else c), viewModelScope)
    fun pickChip(c: String) { chip = c; home = mk(c) }

    /* search */
    var query by mutableStateOf(""); private set
    var sugg by mutableStateOf(listOf<String>()); private set
    var results by mutableStateOf<Feed?>(null); private set
    var recent by mutableStateOf(Store.searches()); private set
    private var sj: Job? = null
    fun typed(q: String) {
        query = q; sj?.cancel()
        sj = viewModelScope.launch {
            delay(250)
            sugg = if (q.isBlank()) emptyList() else runCatching { Repo.suggest(q) }.getOrDefault(emptyList())
        }
    }
    fun submit(q: String) {
        val t = q.trim(); if (t.isEmpty()) return
        sj?.cancel(); query = t; sugg = emptyList()
        recent = (listOf(t) + recent.filter { it != t }).take(15); Store.saveSearches(recent)
        results = Feed(Repo.search(t), viewModelScope).also { it.more() }
    }

    /* library */
    var history by mutableStateOf(Store.vids("h")); private set
    var liked by mutableStateOf(Store.vids("l")); private set
    var later by mutableStateOf(Store.vids("w")); private set
    private fun flip(l: List<Vid>, v: Vid) = if (l.any { it.url == v.url }) l.filter { it.url != v.url } else listOf(v) + l
    fun toggleLiked(v: Vid) { liked = flip(liked, v); Store.saveVids("l", liked) }
    fun toggleLater(v: Vid) { later = flip(later, v); Store.saveVids("w", later) }
    fun clearHistory() { history = emptyList(); Store.saveVids("h", history) }

    /* subscriptions & channel */
    var subs by mutableStateOf(Store.subs()); private set
    private var subFeed: Feed? = null
    fun isSub(url: String) = subs.any { it.url == url }
    fun toggleSub(s: Sub) {
        subs = if (isSub(s.url)) subs.filter { it.url != s.url } else listOf(s) + subs
        Store.saveSubs(subs); subFeed = null
    }
    fun subscriptionFeed(): Feed = subFeed ?: Feed(Repo.subs(subs), viewModelScope).also { subFeed = it }

    var chan by mutableStateOf<ChanUi?>(null); private set
    var chanErr by mutableStateOf<String?>(null); private set
    fun openChannel(url: String) {
        chan = null; chanErr = null
        viewModelScope.launch {
            try {
                val c = Repo.channel(url)
                chan = ChanUi(c, Feed({ p -> if (p == null) c.first else c.more(p) }, viewModelScope).also { it.more() })
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { chanErr = e.message?.take(140) ?: "Couldn't load this channel" }
        }
    }

    /* playback */
    var cur by mutableStateOf<Vid?>(null); private set
    var info by mutableStateOf<StreamInfo?>(null); private set
    var err by mutableStateOf<String?>(null); private set
    var height by mutableIntStateOf(Store.quality); private set
    var heights by mutableStateOf(listOf<Int>()); private set
    var comments by mutableStateOf<List<Cmt>?>(null); private set
    var related by mutableStateOf(listOf<Vid>()); private set
    var speed by mutableFloatStateOf(1f); private set
    var playing by mutableStateOf(false); private set
    var fs by mutableStateOf(false)
    var pip by mutableStateOf(false)
    var onWatch = false
    private var job: Job? = null

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED) { playing = false; related.firstOrNull()?.let { play(it) } }
        }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            playing = playWhenReady && Engine.exo.playbackState != Player.STATE_ENDED
        }
        override fun onPlayerError(error: PlaybackException) { err = "Playback failed (${error.errorCodeName})" }
    }
    init { Engine.exo.addListener(listener) }
    override fun onCleared() { Engine.exo.removeListener(listener) }

    fun play(v: Vid, force: Boolean = false) {
        if (!force && cur?.url == v.url && info != null) return
        job?.cancel()
        cur = v; info = null; err = null; comments = null; related = emptyList(); Engine.exo.stop()
        job = viewModelScope.launch {
            try {
                val i = Repo.info(v.url)
                heights = Engine.heights(i)
                height = heights.firstOrNull { it <= Store.quality } ?: heights.lastOrNull() ?: Store.quality
                related = i.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toVid() }
                val nv = v.copy(
                    title = i.name ?: v.title, channel = i.uploaderName ?: "", channelUrl = i.uploaderUrl ?: "",
                    thumb = i.thumbnails.pick(360), avatar = i.uploaderAvatars.pick(88),
                    views = i.viewCount, duration = i.duration, date = i.textualUploadDate ?: "",
                )
                info = i; cur = nv
                Engine.start(i, height)
                Engine.exo.setPlaybackSpeed(speed)
                history = (listOf(nv) + history.filter { it.url != nv.url }).take(200); Store.saveVids("h", history)
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { err = e.message?.take(160) ?: "Couldn't load this video" }
            val c = runCatching { Repo.comments(v.url) }.getOrDefault(emptyList())
            ensureActive(); comments = c
        }
    }

    fun retry() { cur?.let { play(it, force = true) } }
    fun setQuality(h: Int) { val i = info ?: return; height = h; Store.quality = h; Engine.start(i, h, Engine.exo.currentPosition) }
    fun setSpeed(s: Float) { speed = s; Engine.exo.setPlaybackSpeed(s) }
    fun stop() { job?.cancel(); Engine.exo.stop(); Engine.exo.clearMediaItems(); cur = null; info = null; playing = false; fs = false }
}
