package dev.opentube

import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage

val Red = Color(0xFFFF0033)

class Nav(
    val video: (Vid) -> Unit, val channel: (String) -> Unit, val search: () -> Unit,
    val back: () -> Unit, val pip: () -> Unit,
)

/* ---------- helpers ---------- */

private fun trim1(d: Double) = if (d >= 100) "%.0f".format(d) else "%.1f".format(d).removeSuffix(".0")
fun short(n: Long): String = when {
    n >= 1_000_000_000 -> trim1(n / 1e9) + "B"
    n >= 1_000_000 -> trim1(n / 1e6) + "M"
    n >= 1_000 -> trim1(n / 1e3) + "K"
    else -> n.toString()
}
fun fmtDur(s: Long): String {
    val h = s / 3600; val m = s % 3600 / 60; val x = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, x) else "%d:%02d".format(m, x)
}
fun meta(v: Vid) = listOfNotNull(
    v.channel.ifBlank { null }, if (v.views >= 0) "${short(v.views)} views" else null, v.date.ifBlank { null },
).joinToString(" \u2022 ")
fun share(c: Context, v: Vid) = c.startActivity(Intent.createChooser(
    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, v.url), null))

@Composable fun TubeTheme(content: @Composable () -> Unit) {
    val cs = if (isSystemInDarkTheme()) darkColorScheme(
        primary = Red, background = Color(0xFF0F0F0F), surface = Color(0xFF0F0F0F),
        onBackground = Color.White, onSurface = Color.White,
        surfaceVariant = Color(0xFF272727), onSurfaceVariant = Color(0xFFAAAAAA),
    ) else lightColorScheme(
        primary = Red, background = Color.White, surface = Color.White,
        onBackground = Color(0xFF0F0F0F), onSurface = Color(0xFF0F0F0F),
        surfaceVariant = Color(0xFFF2F2F2), onSurfaceVariant = Color(0xFF606060),
    )
    MaterialTheme(colorScheme = cs, content = content)
}

/* ---------- building blocks ---------- */

@Composable fun Logo() = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(26.dp).clip(CircleShape).background(Red), Alignment.Center) {
        Icon(Icons.Filled.PlayArrow, null, Modifier.size(18.dp), tint = Color.White)
    }
    Spacer(Modifier.width(6.dp))
    Text("YouTube", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp)
}

@Composable fun Avatar(url: String, name: String, size: Dp, mod: Modifier = Modifier) {
    Box(mod.size(size).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), Alignment.Center) {
        Text(name.take(1).uppercase(), fontSize = (size.value / 2.4).sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (url.isNotBlank()) AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable fun Pill(label: String, selected: Boolean = false, icon: ImageVector? = null, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) cs.onBackground else cs.surfaceVariant)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val c = if (selected) cs.background else cs.onBackground
        if (icon != null) { Icon(icon, null, Modifier.size(18.dp), tint = c); Spacer(Modifier.width(6.dp)) }
        Text(label, color = c, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable fun Empty(text: String, action: String? = null, onAction: () -> Unit = {}) =
    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        if (action != null) TextButton(onClick = onAction) { Text(action, color = Red) }
    }

@Composable fun SubButton(vm: AppVm, s: Sub) {
    val on = vm.isSub(s.url); val cs = MaterialTheme.colorScheme
    Box(Modifier.clip(RoundedCornerShape(50)).background(if (on) cs.surfaceVariant else cs.onBackground)
        .clickable { vm.toggleSub(s) }.padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(if (on) "Subscribed" else "Subscribe", color = if (on) cs.onBackground else cs.background,
            fontWeight = FontWeight.Medium, fontSize = 14.sp)
    }
}

@Composable fun VideoCard(v: Vid, vm: AppVm, nav: Nav) {
    val ctx = LocalContext.current; val cs = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clickable { nav.video(v) }.padding(horizontal = 12.dp).padding(bottom = 18.dp)) {
        Box {
            AsyncImage(v.thumb, null, Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(12.dp))
                .background(cs.surfaceVariant), contentScale = ContentScale.Crop)
            if (v.duration > 0) Text(fmtDur(v.duration), Modifier.align(Alignment.BottomEnd).padding(8.dp)
                .background(Color(0xCC000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 1.dp),
                color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        Row(Modifier.padding(top = 10.dp)) {
            Avatar(v.avatar, v.channel, 36.dp, Modifier.clickable(enabled = v.channelUrl.isNotBlank()) { nav.channel(v.channelUrl) })
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium)
                Text(meta(v), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = cs.onSurfaceVariant)
            }
            Box {
                IconButton(onClick = { menu = true }, Modifier.size(28.dp)) { Icon(Icons.Filled.MoreVert, "More") }
                DropdownMenu(menu, { menu = false }) {
                    val saved = vm.later.any { it.url == v.url }
                    DropdownMenuItem({ Text(if (saved) "Remove from Watch later" else "Save to Watch later") }, { vm.toggleLater(v); menu = false })
                    DropdownMenuItem({ Text("Share") }, { share(ctx, v); menu = false })
                }
            }
        }
    }
}

/** Infinite list. `header` items are placed above the videos. */
@Composable fun VideoList(feed: Feed, vm: AppVm, nav: Nav, header: (LazyListScope.() -> Unit)? = null) {
    val st = rememberLazyListState()
    LaunchedEffect(feed) { if (feed.items.isEmpty()) feed.more() }
    LaunchedEffect(st, feed) {
        snapshotFlow { st.layoutInfo.visibleItemsInfo.lastOrNull()?.index to st.layoutInfo.totalItemsCount }
            .collect { (last, total) -> if (last != null && last >= total - 4) feed.more() }
    }
    LazyColumn(Modifier.fillMaxSize(), st) {
        header?.invoke(this)
        items(feed.items, key = { it.url }) { VideoCard(it, vm, nav) }
        item {
            when {
                feed.loading -> Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { CircularProgressIndicator(color = Red, strokeWidth = 3.dp) }
                feed.error != null -> Empty(feed.error!!, "Try again") { feed.more() }
            }
        }
    }
}

/* ---------- screens ---------- */

@Composable fun HomeScreen(vm: AppVm, nav: Nav) = Column(Modifier.fillMaxSize()) {
    Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Logo(); Spacer(Modifier.weight(1f))
        IconButton(onClick = nav.search) { Icon(Icons.Outlined.Search, "Search") }
    }
    LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(vm.chips) { c -> Pill(c, c == vm.chip) { vm.pickChip(c) } }
    }
    Spacer(Modifier.height(12.dp))
    VideoList(vm.home, vm, nav)
}

@Composable fun SearchScreen(vm: AppVm, nav: Nav) {
    val fm = LocalFocusManager.current; val cs = MaterialTheme.colorScheme
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (vm.results == null) fr.requestFocus() }
    Column(Modifier.fillMaxSize()) {
        TextField(
            value = vm.query, onValueChange = vm::typed, singleLine = true, shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(12.dp).focusRequester(fr),
            placeholder = { Text("Search") },
            leadingIcon = { Icon(Icons.Outlined.Search, null) },
            trailingIcon = { if (vm.query.isNotEmpty()) IconButton({ vm.typed("") }) { Icon(Icons.Filled.Close, "Clear") } },
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                focusedContainerColor = cs.surfaceVariant, unfocusedContainerColor = cs.surfaceVariant),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.submit(vm.query); fm.clearFocus() }),
        )
        val res = vm.results
        if (res == null || vm.sugg.isNotEmpty()) {
            val blank = vm.query.isBlank()
            LazyColumn {
                items(if (blank) vm.recent else vm.sugg) { t ->
                    Row(Modifier.fillMaxWidth().clickable { vm.submit(t); fm.clearFocus() }.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (blank) Icons.Filled.History else Icons.Outlined.Search, null, tint = cs.onSurfaceVariant)
                        Spacer(Modifier.width(16.dp))
                        Text(t, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        IconButton({ vm.typed(t) }, Modifier.size(24.dp)) { Icon(Icons.Filled.NorthWest, "Use text", tint = cs.onSurfaceVariant) }
                    }
                }
            }
        } else VideoList(res, vm, nav)
    }
}

@Composable fun SubsScreen(vm: AppVm, nav: Nav) = Column(Modifier.fillMaxSize()) {
    Text("Subscriptions", Modifier.padding(16.dp), fontSize = 22.sp, fontWeight = FontWeight.Bold)
    if (vm.subs.isEmpty()) Empty("Subscribe to a channel and its latest videos will show up here.") else {
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(vm.subs, key = { it.url }) { s ->
                Column(Modifier.width(64.dp).clickable { nav.channel(s.url) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(s.avatar, s.name, 52.dp)
                    Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        VideoList(vm.subscriptionFeed(), vm, nav)
    }
}

@Composable fun LibraryScreen(vm: AppVm, nav: Nav) {
    var tab by remember { mutableIntStateOf(0) }
    val list = when (tab) { 0 -> vm.history; 1 -> vm.liked; else -> vm.later }
    Column(Modifier.fillMaxSize()) {
        Text("Library", Modifier.padding(16.dp), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("History", "Liked", "Watch later").forEachIndexed { i, n -> Pill(n, tab == i) { tab = i } }
            Spacer(Modifier.weight(1f))
            if (tab == 0 && list.isNotEmpty()) TextButton(onClick = vm::clearHistory) { Text("Clear", color = Red) }
        }
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) Empty(when (tab) { 0 -> "Videos you watch appear here."; 1 -> "Videos you like appear here."; else -> "Save videos from the \u22EE menu to watch them later." })
        else LazyColumn { items(list, key = { it.url }) { VideoCard(it, vm, nav) } }
    }
}

@Composable fun ChannelScreen(vm: AppVm, nav: Nav) = Column(Modifier.fillMaxSize()) {
    IconButton(onClick = nav.back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
    val ui = vm.chan
    when {
        ui != null -> VideoList(ui.feed, vm, nav) {
            item {
                Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(ui.c.sub.avatar, ui.c.sub.name, 72.dp)
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(ui.c.sub.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            if (ui.c.subs >= 0) Text("${short(ui.c.subs)} subscribers", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (ui.c.desc.isNotBlank()) Text(ui.c.desc, Modifier.padding(top = 12.dp), maxLines = 3, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp)); SubButton(vm, ui.c.sub)
                }
            }
        }
        vm.chanErr != null -> Empty(vm.chanErr!!)
        else -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Red) }
    }
}

/* ---------- player ---------- */

@Composable private fun TapZone(mod: Modifier, seekMs: Long, pv: PlayerView?) {
    val view by rememberUpdatedState(pv)
    Box(mod.pointerInput(Unit) {
        detectTapGestures(
            onTap = { view?.let { if (it.isControllerFullyVisible) it.hideController() else it.showController() } },
            onDoubleTap = {
                val p = Engine.exo
                val max = if (p.duration > 0) p.duration else Long.MAX_VALUE
                p.seekTo((p.currentPosition + seekMs).coerceIn(0L, max))
            },
        )
    })
}

@Composable fun PlayerBox(vm: AppVm, mod: Modifier) {
    var pv by remember { mutableStateOf<PlayerView?>(null) }
    Box(mod.background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = Engine.exo
                    setShowNextButton(false); setShowPreviousButton(false)
                    controllerShowTimeoutMs = 3000
                    setFullscreenButtonClickListener { vm.fs = !vm.fs }
                }
            },
            update = { it.useController = !vm.pip; if (pv !== it) pv = it },
            onRelease = { it.player = null },
            modifier = Modifier.fillMaxSize(),
        )
        if (!vm.pip) { // double-tap left / right thirds to seek 10s, centre stays free for the controls
            TapZone(Modifier.align(Alignment.TopStart).fillMaxWidth(0.3f).fillMaxHeight(0.65f), -10_000, pv)
            TapZone(Modifier.align(Alignment.TopEnd).fillMaxWidth(0.3f).fillMaxHeight(0.65f), 10_000, pv)
        }
        val e = vm.err
        when {
            e != null -> Column(Modifier.align(Alignment.Center).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(e, color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center)
                TextButton(onClick = vm::retry) { Text("Try again", color = Red) }
            }
            vm.info == null -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White, strokeWidth = 3.dp)
        }
    }
}

@Composable fun WatchScreen(vm: AppVm, nav: Nav) {
    val v = vm.cur ?: return
    val ctx = LocalContext.current; val cs = MaterialTheme.colorScheme
    val lazy = rememberLazyListState()
    var descOpen by remember(v.url) { mutableStateOf(false) }
    var qMenu by remember { mutableStateOf(false) }
    var sMenu by remember { mutableStateOf(false) }
    LaunchedEffect(v.url) { lazy.scrollToItem(0) }
    BackHandler(vm.fs) { vm.fs = false }
    val full = vm.fs || vm.pip
    Column(Modifier.fillMaxSize()) {
        PlayerBox(vm, if (full) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f))
        if (!full) LazyColumn(Modifier.fillMaxSize(), lazy) {
            item {
                Column(Modifier.padding(12.dp)) {
                    Text(v.title.ifBlank { "Loading\u2026" }, fontSize = 18.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold)
                    Text(listOfNotNull(if (v.views >= 0) "${short(v.views)} views" else null, v.date.ifBlank { null }).joinToString(" \u2022 "),
                        fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                }
            }
            if (v.channelUrl.isNotBlank()) item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.weight(1f).clickable { nav.channel(v.channelUrl) }, verticalAlignment = Alignment.CenterVertically) {
                        Avatar(v.avatar, v.channel, 40.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(v.channel, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            vm.info?.uploaderSubscriberCount?.takeIf { it >= 0 }?.let {
                                Text("${short(it)} subscribers", fontSize = 12.sp, color = cs.onSurfaceVariant)
                            }
                        }
                    }
                    SubButton(vm, Sub(v.channelUrl, v.channel, v.avatar))
                }
            }
            item {
                LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { val on = vm.liked.any { it.url == v.url }
                        Pill(if (on) "Liked" else "Like", on, if (on) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp) { vm.toggleLiked(v) } }
                    item { Pill("Share", icon = Icons.Filled.Share) { share(ctx, v) } }
                    item { val on = vm.later.any { it.url == v.url }
                        Pill(if (on) "Saved" else "Save", on, if (on) Icons.Filled.WatchLater else Icons.Outlined.WatchLater) { vm.toggleLater(v) } }
                    if (vm.heights.isNotEmpty()) item {
                        Box {
                            Pill("${vm.height}p", icon = Icons.Filled.HighQuality) { qMenu = true }
                            DropdownMenu(qMenu, { qMenu = false }) {
                                vm.heights.forEach { h ->
                                    DropdownMenuItem({ Text("${h}p" + if (h == vm.height) "  \u2713" else "") }, { vm.setQuality(h); qMenu = false })
                                }
                            }
                        }
                    }
                    item {
                        Box {
                            Pill(if (vm.speed == 1f) "Speed" else "${vm.speed}x", icon = Icons.Filled.Speed) { sMenu = true }
                            DropdownMenu(sMenu, { sMenu = false }) {
                                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                                    DropdownMenuItem({ Text("${s}x" + if (s == vm.speed) "  \u2713" else "") }, { vm.setSpeed(s); sMenu = false })
                                }
                            }
                        }
                    }
                    item { Pill("Mini window", icon = Icons.Filled.PictureInPictureAlt) { nav.pip() } }
                }
            }
            val desc = vm.info?.description?.content.orEmpty()
            if (desc.isNotBlank()) item {
                Text(desc, Modifier.fillMaxWidth().padding(horizontal = 12.dp).clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant)
                    .clickable { descOpen = !descOpen }.padding(12.dp),
                    maxLines = if (descOpen) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
            }
            item {
                val c = vm.comments
                Text(when { c == null -> "Loading comments\u2026"; c.isEmpty() -> "Comments are off or unavailable"; else -> "Comments" },
                    Modifier.padding(12.dp), fontWeight = FontWeight.SemiBold)
            }
            items(vm.comments.orEmpty().take(15)) { c ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Avatar(c.avatar, c.author, 32.dp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(c.author, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = cs.onSurfaceVariant)
                        Text(c.text, fontSize = 14.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
                        if (c.likes > 0) Text("${short(c.likes.toLong())} likes", fontSize = 11.sp, color = cs.onSurfaceVariant)
                    }
                }
            }
            item { Spacer(Modifier.height(12.dp)) }
            items(vm.related) { VideoCard(it, vm, nav) }
        }
    }
}

@Composable fun MiniPlayer(vm: AppVm, nav: Nav) {
    val v = vm.cur ?: return
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).clickable { nav.video(v) }.padding(8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(v.thumb, null, Modifier.height(44.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(6.dp)), contentScale = ContentScale.Crop)
        Text(v.title.ifBlank { "Loading\u2026" }, Modifier.weight(1f).padding(horizontal = 10.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
        IconButton({ Engine.exo.playWhenReady = !Engine.exo.playWhenReady }) {
            Icon(if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, if (vm.playing) "Pause" else "Play")
        }
        IconButton({ vm.stop() }) { Icon(Icons.Filled.Close, "Close") }
    }
}

/* ---------- root ---------- */

private class Tab(val route: String, val label: String, val on: ImageVector, val off: ImageVector)

@Composable fun Root(vm: AppVm, pendingUrl: String?, consume: () -> Unit, pip: () -> Unit) {
    val nc = rememberNavController(); val cs = MaterialTheme.colorScheme
    val route = nc.currentBackStackEntryAsState().value?.destination?.route
    LaunchedEffect(route) { vm.onWatch = route == "watch"; if (route != "watch") vm.fs = false }
    fun go(r: String) = nc.navigate(r) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true }
    val nav = remember {
        Nav(
            video = { vm.play(it); nc.navigate("watch") { launchSingleTop = true } },
            channel = { vm.openChannel(it); nc.navigate("chan") { launchSingleTop = true } },
            search = { go("search") }, back = { nc.popBackStack() }, pip = pip,
        )
    }
    LaunchedEffect(pendingUrl) { pendingUrl?.let { vm.play(Vid.of(it)); nc.navigate("watch") { launchSingleTop = true }; consume() } }
    val tabs = listOf(
        Tab("home", "Home", Icons.Filled.Home, Icons.Outlined.Home),
        Tab("search", "Search", Icons.Filled.Search, Icons.Outlined.Search),
        Tab("subs", "Subscriptions", Icons.Filled.Subscriptions, Icons.Outlined.Subscriptions),
        Tab("lib", "Library", Icons.Filled.VideoLibrary, Icons.Outlined.VideoLibrary),
    )
    Scaffold(
        containerColor = cs.background,
        contentWindowInsets = if (vm.fs || vm.pip) WindowInsets(0, 0, 0, 0) else ScaffoldDefaults.contentWindowInsets,
        bottomBar = {
            if (route != "watch") Column {
                if (vm.cur != null) MiniPlayer(vm, nav)
                NavigationBar(containerColor = cs.background) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route, onClick = { go(t.route) },
                            icon = { Icon(if (route == t.route) t.on else t.off, t.label) },
                            label = { Text(t.label, fontSize = 10.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Color.Transparent, selectedIconColor = cs.onBackground, selectedTextColor = cs.onBackground,
                                unselectedIconColor = cs.onBackground, unselectedTextColor = cs.onBackground),
                        )
                    }
                }
            }
        },
    ) { pad ->
        NavHost(nc, "home", Modifier.padding(pad)) {
            composable("home") { HomeScreen(vm, nav) }
            composable("search") { SearchScreen(vm, nav) }
            composable("subs") { SubsScreen(vm, nav) }
            composable("lib") { LibraryScreen(vm, nav) }
            composable("chan") { ChannelScreen(vm, nav) }
            composable("watch") { WatchScreen(vm, nav) }
        }
    }
}
