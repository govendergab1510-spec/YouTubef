package dev.opentube

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.ListExtractor
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabs
import org.schabi.newpipe.extractor.comments.CommentsInfo
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.search.SearchExtractor
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType
import java.util.concurrent.TimeUnit
import kotlin.math.abs

const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"

/* ---------- networking ---------- */

object Net {
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()
}

class Dl(private val c: OkHttpClient) : Downloader() {
    override fun execute(request: Request): Response {
        val m = request.httpMethod()
        val body = request.dataToSend()?.toRequestBody()
            ?: if (m == "POST" || m == "PUT") ByteArray(0).toRequestBody() else null
        val b = okhttp3.Request.Builder().url(request.url()).method(m, body).header("User-Agent", UA)
        request.headers().forEach { (k, v) -> b.removeHeader(k); v.forEach { b.addHeader(k, it) } }
        c.newCall(b.build()).execute().use { r ->
            if (r.code == 429) throw ReCaptchaException("Rate limited by the service", request.url())
            return Response(r.code, r.message, r.headers.toMultimap(), r.body?.string(), r.request.url.toString())
        }
    }
}

/* ---------- models ---------- */

data class Vid(
    val url: String, val title: String, val channel: String, val channelUrl: String,
    val thumb: String, val avatar: String, val views: Long, val duration: Long, val date: String,
) {
    companion object { fun of(url: String) = Vid(url, "", "", "", "", "", -1, 0, "") }
}
data class Sub(val url: String, val name: String, val avatar: String)
data class Cmt(val author: String, val text: String, val likes: Int, val avatar: String)
class Pg(val items: List<Vid>, val next: Page?)
typealias Loader = suspend (Page?) -> Pg
class Chan(val sub: Sub, val subs: Long, val desc: String, val first: Pg, val more: Loader)

fun List<Image>.pick(h: Int): String = minByOrNull { abs(it.height - h) }?.url ?: ""

fun StreamInfoItem.toVid(chName: String = "", chUrl: String = "", chAvatar: String = "") = Vid(
    url, name ?: "", uploaderName ?: chName, uploaderUrl ?: chUrl, thumbnails.pick(360),
    uploaderAvatars.pick(88).ifEmpty { chAvatar }, viewCount, duration, textualUploadDate ?: "",
)

/* ---------- YouTube data (NewPipeExtractor) ---------- */

object Repo {
    private val yt get() = ServiceList.YouTube
    private suspend fun <T> io(f: () -> T) = withContext(Dispatchers.IO) { f() }

    private fun ListExtractor.InfoItemsPage<*>.pg() =
        Pg(items.filterIsInstance<StreamInfoItem>().map { it.toVid() }, nextPage)

    fun trending(): Loader {
        var ex: org.schabi.newpipe.extractor.kiosk.KioskExtractor<*>? = null
        val fallback = search("popular videos")
        return { p ->
            val first = if (p == null) runCatching {
                io {
                    val e = yt.kioskList.defaultKioskExtractor
                    e.fetchPage(); ex = e; e.initialPage.pg()
                }
            }.getOrNull()?.takeIf { it.items.isNotEmpty() } else null
            when {
                first != null -> first
                p != null && ex != null -> io { ex!!.getPage(p).pg() }
                else -> fallback(p)
            }
        }
    }

    fun search(q: String): Loader {
        var ex: SearchExtractor? = null
        return { p ->
            io {
                val e = ex ?: yt.getSearchExtractor(q, listOf(YoutubeSearchQueryHandlerFactory.VIDEOS), "")
                    .also { it.fetchPage(); ex = it }
                if (p == null) e.initialPage.pg() else e.getPage(p).pg()
            }
        }
    }

    suspend fun suggest(q: String): List<String> = io { yt.suggestionExtractor.suggestionList(q) }

    suspend fun info(url: String): StreamInfo = io { StreamInfo.getInfo(yt, url) }

    suspend fun comments(url: String): List<Cmt> = io {
        CommentsInfo.getInfo(yt, url).relatedItems.map {
            Cmt(it.uploaderName ?: "", it.commentText?.content ?: "", it.likeCount, it.uploaderAvatars.pick(64))
        }
    }

    suspend fun channel(url: String): Chan = io {
        val ci = ChannelInfo.getInfo(yt, url)
        val tab = ci.tabs.firstOrNull { ChannelTabs.VIDEOS in it.contentFilters } ?: ci.tabs.first()
        val ti = ChannelTabInfo.getInfo(yt, tab)
        val avatar = ci.avatars.pick(160)
        fun conv(l: List<*>) = l.filterIsInstance<StreamInfoItem>().map { it.toVid(ci.name ?: "", ci.url, avatar) }
        Chan(
            Sub(ci.url, ci.name ?: "", avatar), ci.subscriberCount, ci.description ?: "",
            Pg(conv(ti.relatedItems), ti.nextPage),
        ) { p -> io { ChannelTabInfo.getMoreItems(yt, tab, p!!).let { Pg(conv(it.items), it.nextPage) } } }
    }

    /** Latest uploads from subscribed channels, interleaved so every channel shows up. */
    fun subs(list: List<Sub>): Loader = { p ->
        if (p != null || list.isEmpty()) Pg(emptyList(), null) else {
            val lists = coroutineScope {
                list.take(24).map { s -> async { runCatching { channel(s.url).first.items.take(5) }.getOrDefault(emptyList()) } }.awaitAll()
            }
            val out = mutableListOf<Vid>()
            for (i in 0 until 5) lists.forEach { l -> l.getOrNull(i)?.let(out::add) }
            Pg(out, null)
        }
    }
}

/* ---------- local storage (history, likes, subscriptions) ---------- */

object Store {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("tube", Context.MODE_PRIVATE) }

    private fun Vid.json() = JSONObject().put("u", url).put("t", title).put("c", channel).put("cu", channelUrl)
        .put("th", thumb).put("av", avatar).put("v", views).put("d", duration).put("ds", date)
    private fun JSONObject.vid() = Vid(getString("u"), optString("t"), optString("c"), optString("cu"),
        optString("th"), optString("av"), optLong("v", -1), optLong("d"), optString("ds"))

    fun vids(k: String): List<Vid> = runCatching {
        JSONArray(sp.getString(k, "[]")).let { a -> List(a.length()) { a.getJSONObject(it).vid() } }
    }.getOrDefault(emptyList())
    fun saveVids(k: String, l: List<Vid>) = sp.edit().putString(k, JSONArray(l.map { it.json() }).toString()).apply()

    fun subs(): List<Sub> = runCatching {
        JSONArray(sp.getString("s", "[]")).let { a -> List(a.length()) { a.getJSONObject(it).let { o -> Sub(o.getString("u"), o.optString("n"), o.optString("a")) } } }
    }.getOrDefault(emptyList())
    fun saveSubs(l: List<Sub>) = sp.edit().putString("s", JSONArray(l.map { JSONObject().put("u", it.url).put("n", it.name).put("a", it.avatar) }).toString()).apply()

    fun searches(): List<String> = (sp.getString("q", "") ?: "").split("\n").filter { it.isNotBlank() }
    fun saveSearches(l: List<String>) = sp.edit().putString("q", l.joinToString("\n")).apply()

    var quality: Int
        get() = sp.getInt("h", 720)
        set(v) = sp.edit().putInt("h", v).apply()
}

/* ---------- player (Media3 / ExoPlayer) ---------- */

object Engine {
    lateinit var exo: ExoPlayer
    private val ds = DefaultHttpDataSource.Factory().setUserAgent(UA)
        .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(15_000).setReadTimeoutMs(20_000)

    fun init(c: Context) {
        exo = ExoPlayer.Builder(c)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(15_000, 50_000, 1_500, 3_000).build())
            .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
    }

    private val StreamInfo.live get() = streamType == StreamType.LIVE_STREAM && !hlsUrl.isNullOrEmpty()
    private fun vo(i: StreamInfo) = i.videoOnlyStreams.filter { it.format == MediaFormat.MPEG_4 && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
    private fun au(i: StreamInfo) = i.audioStreams.filter { it.format == MediaFormat.M4A && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }.maxByOrNull { it.averageBitrate }
    private fun mx(i: StreamInfo) = i.videoStreams.filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }

    /** Selectable resolutions, best first. Empty for live streams (adaptive HLS). */
    fun heights(i: StreamInfo): List<Int> {
        if (i.live) return emptyList()
        val s = if (vo(i).isNotEmpty() && au(i) != null) vo(i) else mx(i)
        return s.map { it.height }.filter { it > 0 }.distinct().sortedDescending()
    }

    fun build(i: StreamInfo, h: Int): MediaSource {
        val meta = MediaMetadata.Builder().setTitle(i.name).setArtist(i.uploaderName)
            .setArtworkUri(i.thumbnails.pick(480).takeIf { it.isNotEmpty() }?.let(Uri::parse)).build()
        fun item(u: String) = MediaItem.Builder().setUri(u).setMediaMetadata(meta).build()
        if (i.live) return HlsMediaSource.Factory(ds).createMediaSource(item(i.hlsUrl))
        val pf = ProgressiveMediaSource.Factory(ds)
        val v = vo(i); val a = au(i)
        if (v.isNotEmpty() && a != null) {
            val pool = v.filter { it.height <= h }.ifEmpty { listOf(v.minBy { it.height }) }
            val top = pool.maxOf { it.height }
            val s = pool.filter { it.height == top }.let { l -> l.firstOrNull { it.codec?.startsWith("avc1") == true } ?: l.first() }
            return MergingMediaSource(pf.createMediaSource(item(s.content)), pf.createMediaSource(item(a.content)))
        }
        val m = mx(i)
        require(m.isNotEmpty()) { "No playable stream found for this video" }
        val s = m.filter { it.height <= h }.maxByOrNull { it.height } ?: m.minBy { it.height }
        return pf.createMediaSource(item(s.content))
    }

    fun start(i: StreamInfo, h: Int, pos: Long = 0) {
        exo.setMediaSource(build(i, h), pos)
        exo.prepare()
        exo.playWhenReady = true
    }
}
