package dev.opentube

import android.app.Application
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.Localization

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        NewPipe.init(Dl(Net.http), Localization("en", "US"))
        Engine.init(this)
    }
}
